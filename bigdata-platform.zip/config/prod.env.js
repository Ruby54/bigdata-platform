'use strict'
module.exports = {
  NODE_ENV: '"production"',
  BASE_API: '"http://gmalldata.atguigu.cn:8866"',
}

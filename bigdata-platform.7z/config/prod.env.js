'use strict'
module.exports = {
  NODE_ENV: '"production"',
  BASE_API: '"http://39.98.123.211:8866"',
}
